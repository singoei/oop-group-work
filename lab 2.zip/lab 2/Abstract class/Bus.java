public class Bus extends vehicle{
    public void accelerate(){
        System.out.println("Acceleration : " +speed );
    }
    public void stop() {
        System.out.println("Motion :" +motion);
    }
    public void gas(){
        System.out.println("Tank : " +tank);
    }
}