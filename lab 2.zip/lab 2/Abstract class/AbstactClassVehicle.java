abstract class vehicle{
   
    int speed;
    String motion;
    String tank;

    void setdata(int speed, String motion, String tank){
      
        this.speed =speed;
        this.motion =motion;
        this.tank = tank;
    }

    public abstract void accelerate();
    public abstract void stop();
    public abstract void gas();
}