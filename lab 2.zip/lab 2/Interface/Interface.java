public interface Automobile {
    public void accelerate(int speed);
    public void stop(String motion);
    public void gas(String tank);
}