public class Sedan implements Automobile {

    int speed;
    String motion;
    String tank;

     public void accelerate(int a) {

        this.speed = a;

        System.out.println("Acceleration : " + speed);
    }

     public void stop(String stop) {

        this.motion = stop;
        System.out.println("Motion : " + motion);
    }

     public void gas(String full) {

        this.tank = full;

        System.out.println("Gas level : " + tank);
    }
}
