class MySedan {
    public static void main(String[] arg) {
        Automobile obj = new Sedan();
        obj.accelerate(70);
        obj.stop("Stop");
        obj.gas("full");

        //Overloading
        obj.accelerate(50);
    }
}
class MyNewSedan extends MySedan {
    int speed;
        public void accelerate(int a) {

            this.speed = a;

            System.out.println("Acceleration : " + speed);
        }
    }

class OverridingTest{
    public static void main(String [] args){
         MyNewSedan obj = new MyNewSedan();
         obj.accelerate(70);
                 
    }
}